package com.cpsc581.colorunlock;

import android.graphics.Color;

public class PatternNode{
    public int slice;
    public int color;
    int strawberry = Color.parseColor("#EC513A");
    int banana = Color.parseColor("#FBE58F");
    int oats = Color.parseColor("#EBC8A2");

    public PatternNode(int slice, int color)
    {
        if (color == strawberry) {
            this.color = color;
            this.slice = slice;

        }
        if (color == banana) {
            this.color = color;
            this.slice = slice;

        }
        if (color == oats) {
            this.color = color;
            this.slice = slice;
        }
    }

    @Override
    public String toString()
    {
        return "{color:"+ color + " slice: " + slice + "}";
    }
}
