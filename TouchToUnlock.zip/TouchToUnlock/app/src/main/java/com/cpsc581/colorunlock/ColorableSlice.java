package com.cpsc581.colorunlock;

import android.animation.Animator;
import android.animation.ArgbEvaluator;
import android.animation.FloatEvaluator;
import android.animation.ValueAnimator;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.widget.ImageView;

import com.devs.vectorchildfinder.VectorChildFinder;
import com.devs.vectorchildfinder.VectorDrawableCompat;

import java.nio.file.Path;

public class ColorableSlice{

    public ImageView parent;
    public ImageView mask;
    public VectorDrawableCompat.VFullPath slice;
    public int maskColor;
    public int id;
    public VectorDrawableCompat.VFullPath path;
    int strawberry = Color.parseColor("#EC513A");
    int banana = Color.parseColor("#FBE58F");
    int oats = Color.parseColor("#EBC8A2");
    public int ver = 0;


    public ColorableSlice(int id, ImageView parent, ImageView mask, VectorDrawableCompat.VFullPath slice, int maskColor)
    {
        this.parent = parent;
        this.mask = mask;
        this.slice = slice;
        this.maskColor = maskColor;
        this.id = id;
    }

    public Animator animateFill(int toColor)
    {

        if (toColor == oats && id ==0) {
            parent.setImageResource(R.drawable.ic_oatswrong2);
            ver++;
        }
        else if (toColor == oats && id ==1 && ver == 1) {
            parent.setImageResource(R.drawable.ic_oatswrong3);
            ver++;
        }
        else if (toColor == oats && id ==1 && ver == 2) {
            parent.setImageResource(R.drawable.ic_oatswrong4);
        }
        else if (toColor == strawberry && id == 0) {
            parent.setImageResource(R.drawable.ic_strawberry);
        }
        else if (toColor == banana && id == 1) {
            parent.setImageResource(R.drawable.ic_banana);
        }
        else if (toColor == oats && id ==2) {
            parent.setImageResource(R.drawable.ic_oats);
        }

        else if (toColor == strawberry && id == 2) {
            parent.setImageResource(R.drawable.ic_strawberrywrong);
        }
        else if (toColor == banana && id == 0) {
            parent.setImageResource(R.drawable.ic_bananawrong);
        }
        else if (toColor == oats && id ==1) {
            parent.setImageResource(R.drawable.ic_oatswrong);
        }
        else if (toColor == strawberry && id == 1) {
            parent.setImageResource(R.drawable.ic_strawberrywrong2);
        }
        else if (toColor == banana && id ==2) {
            parent.setImageResource(R.drawable.ic_bananawrong2);
        }


            int from = slice.getFillColor();
            ValueAnimator animator = ValueAnimator.ofObject(new ArgbEvaluator(), from, toColor);
            animator.setDuration(500);
            animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {

                @Override
                public void onAnimationUpdate(ValueAnimator animator) {
                    slice.setFillColor((int) animator.getAnimatedValue());
                    parent.invalidate();
                }

            });
            animator.start();

            return animator;

    }

    public void animatePath()
    {
        ValueAnimator animator = ValueAnimator.ofObject(new FloatEvaluator(), 0f, 1f);
        animator.setDuration(1000);
        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {

            @Override
            public void onAnimationUpdate(ValueAnimator animator) {
                slice.setTrimPathEnd((float) animator.getAnimatedValue());
                parent.invalidate();
            }
        });
        animator.start();
    }

    public void setFill(int color)
    {
        slice.setFillColor(color);
        parent.invalidate();
    }
}
